<h1>This source code is related to the client part</h1>
<b>This is an open source mini-app that includes all parts of a Telegram clicker game</b>

<hr>
<b>Implemented sections :</b>
<ul>
  <li>User authentication with Json Web Token (JWT)</li>
  <li>Admin panel Telegram (users list and public messages)</li>
  <li>Making a squad and joining or leaving</li>
  <li>Credit transfer and credit conversion to other currencies</li>
  <li>The ability to collect and receive rewards</li>
  <li>Level up to get more coins and buy or change skins</li>  
  <li>The ability to create challenges for users with prizes</li>  
</ul>
<hr>

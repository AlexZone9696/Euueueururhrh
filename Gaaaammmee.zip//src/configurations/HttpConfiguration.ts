export const BASE_URL = "https://bincoin.shop";
export const BOT_URL = "https://t.me/Bin_CoinBot";
import type BaseModel from "./baseModel";

export default interface CurrencyModel{
    name: string;
    image: string;
    price : number;
}

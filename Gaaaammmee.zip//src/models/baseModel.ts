export default interface BaseModel {
    id: string;
    dateCreation: Date;
    dateModified: Date;
}

export default interface TokenModel{
    accessToken: string;
    accessTokenExpiration: Date;
}

export default interface PaginationModel<T> {
    result: T,
    countTotal : number
}